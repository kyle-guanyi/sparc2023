import json
import os
import pymysql
import subprocess
import boto3
from datetime import date

import sys
import logging

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
rds_host = os.environ['RDS_HOST']
db_name = os.environ['DB_NAME']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=rds_host, user=user_name, passwd=password, db=db_name, connect_timeout=5)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit()

logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")


def lambda_handler(event, context):
    # Database connection info
    db_host = "sparc-db.c56gikbu12n4.us-east-1.rds.amazonaws.com"
    db_user = "admin"
    db_password = "sparc2023"
    db_name = "SPARC_DB"
    db_port = 3306

    # S3 bucket info
    s3_bucket = "kevin-testbucket-sparc"

    # Generate the filename with timestamp
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"{db_name}_snapshot_{timestamp}.sql"

    # MySQL dump command
    dump_command = f"mysqldump -h {db_host} -u {db_user} -p{db_password} {db_name}"

    # Execute the MySQL dump command and upload to S3
    try:
        with subprocess.Popen(dump_command, stdout=subprocess.PIPE, shell=True) as process:
            s3_key = os.path.join(s3_folder, filename) if s3_folder else filename
            s3 = boto3.client("s3")
            logger.info("Database snapshot:  " + filename + " is being copied to new bucket " + s3_bucket)
            s3.upload_fileobj(process.stdout, s3_bucket, s3_key)
        return {"statusCode": 200, "body": f"Snapshot successfully uploaded to S3: {filename}"}
    except Exception as e:
        return {"statusCode": 500, "body": f"Error: {str(e)}"}
